# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Thu Jun 10 10:56:39 2021)---
python
pip install 
pip install dash
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
python3
pip install dash_html_components
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')

## ---(Sun Jun 20 19:48:49 2021)---
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard/app_final.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard')
pip install dash_bootstrap_components
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard/app_final.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard')
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-video-detection/app.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-video-detection')
pip install cv2
pip install dash_player
pip install requirements.txt
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-video-detection/app.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-video-detection')
pip install cvw
pip install cv2
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-soccer-analytics/app.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-soccer-analytics')
pip install dash_daq
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-soccer-analytics/app.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-soccer-analytics')
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-live-model-training/app.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-live-model-training')
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard/app_final.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard')
runfile('C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard/untitled5.py', wdir='C:/Users/syedamk/dash-sample-apps/apps/dash-fifa-dashboard')

## ---(Mon Jun 21 02:23:43 2021)---
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
pip install
pip install dash_extensions
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
pip install pyplugs
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
pip install pyconfs
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
runfile('C:/Users/syedamk/sc-ka-dashboard/sad/__main__.py', wdir='C:/Users/syedamk/sc-ka-dashboard/sad')
pip-compile requirements.in
pip install requirements.txt
python -m pip install -r requirements.txt
pip install -r requirements.txt

## ---(Mon Jun 21 22:13:09 2021)---
pip install -r requirements.txt

## ---(Mon Jun 21 22:25:54 2021)---
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')

## ---(Tue Jun 22 10:17:06 2021)---
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
$ pip install psycopg2
 pip install psycopg2
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
0689AE
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
pip install psycopg2
runfile('C:/Users/syedamk/.spyder-py3/untitled2.py', wdir='C:/Users/syedamk/.spyder-py3')
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
python -m pip install requests
 pip install requests

## ---(Mon Jun 28 20:58:35 2021)---
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
pip install panda
runfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')
debugfile('C:/Users/syedamk/.spyder-py3/temp.py', wdir='C:/Users/syedamk/.spyder-py3')